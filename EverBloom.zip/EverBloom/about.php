<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>about us</h3>
    <p> <a href="home.php">home</a> / about </p>
</section>

<section class="about">

    <div class="flex">

        <div class="image">
            <img src="images/about-img-1.png" alt="">
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p>At EverBloom, we believe every achievement deserves to be honored with beauty. Our handcrafted bouquets are made with care, combining fresh flowers, elegant design, and a deep sense of meaning to celebrate this special milestone.</p>
            <a href="shop.php" class="btn">shop now</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>what we provide?</h3>
            <p>We provide thoughtfully designed graduation bouquets, complete with premium wrapping and optional personalized messages. Each arrangement is created to make your gift memorable and truly meaningful.</p>
            <a href="contact.php" class="btn">contact us</a>
        </div>

        <div class="image">
            <img src="images/about-img-2.jpeg" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="images/about-img-3.jpg" alt="">
        </div>

        <div class="content">
            <h3>who we are?</h3>
            <p>We are EverBloom — a team passionate about turning graduation moments into lasting memories with beautifully crafted flower bouquets made for proud celebrations.</p>
            <a href="#reviews" class="btn">customer reviews</a>
        </div>

    </div>

</section>

<section class="reviews" id="reviews">

    <h1 class="title">customer reviews</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/pic-1.png" alt="">
            <p>"The bouquet was absolutely stunning! My sister was so touched. The flowers were fresh, beautifully arranged, and delivered on time. Highly recommended!"</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <h3>John</h3>
        </div>

        <div class="box">
            <img src="images/pic-2.png" alt="">
            <p>“EverBloom exceeded my expectations. The wrapping was elegant, and the handwritten message made it extra special. Perfect for graduation day!”</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <h3>Emily</h3>
        </div>

        <div class="box">
            <img src="images/pic-3.png" alt="">
            <p>“Loved the bouquet and the overall look. I just wish the card had a little more space to write a longer message. But still, I'm very happy with my order!”</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Alex</h3>
        </div>

        <div class="box">
            <img src="images/pic-4.png" alt="">
            <p>“So much care went into the arrangement. The flowers were vibrant and fresh, and the whole presentation was flawless. Thank you, EverBloom!”</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <h3>Sarah</h3>
        </div>

        <div class="box">
            <img src="images/pic-5.png" alt="">
            <p>“Very beautiful bouquet, amazing customer service, and quick delivery! EverBloom helped make my nephew’s graduation day even more memorable.”</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <h3>Timothy</h3>
        </div>

        <div class="box">
            <img src="images/pic-6.png" alt="">
            <p>“I've ordered from a few places before, but nothing compares to the quality and service from EverBloom. Quick delivery as always. Truly a wonderful experience.”</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <h3>Shu Hwa</h3>
        </div>

    </div>

</section>











<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>