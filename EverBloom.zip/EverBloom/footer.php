<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="shop.php">Shop</a>
        </div>

        <div class="box">
            <h3>extra links</h3>
            <a href="search_page.php">Search Page</a>
            <a href="wishlist.php">My Wishlist</a>
            <a href="cart.php">My Cart</a>
            <a href="orders.php">My Orders</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <p> <i class="fas fa-phone"></i> 04-1234 6969 (Main Shop) </p>
            <p> <i class="fas fa-phone"></i> 03-5678 6969 (KL Branch) </p>
            <p> <i class="fas fa-envelope"></i> hello@everbloom.com </p>
            <p> <i class="fas fa-map-marker-alt"></i> Penang, Malaysia </p>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#"><i class="fab fa-facebook-f"></i>Facebook</a>
            <a href="#"><i class="fab fa-twitter"></i>Twitter</a>
            <a href="#"><i class="fab fa-instagram"></i>Instagram</a>
            <a href="#"><i class="fab fa-linkedin"></i>LinkedIn</a>
        </div>

    </div>

    <div class="credit">&copy; <?php echo date('Y'); ?> <span>EverBloom, Inc. All rights reserved.</span> </div>

</section>